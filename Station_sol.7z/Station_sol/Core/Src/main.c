/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2025 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "string.h"
#include "stdio.h"
#include <stdlib.h>
#include <ctype.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define SEUIL_ADC 2482

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc;

TIM_HandleTypeDef htim2;

UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
uint8_t rx_data[32]; // Buffer pour recevoir les données
extern volatile uint32_t msCounter;
extern volatile uint8_t flag_interruption_descente;
extern volatile uint8_t Vent_violent;
extern volatile uint32_t digitalValue;

volatile uint16_t motorMoveRequested = 0;  // Changé en uint16_t pour accepter 4000 pas
volatile int motorDirection = 0;
volatile int motorSpeed = 0;
volatile uint8_t EnMouvement = 0; // Flag pour indiquer si le moteur est déjà en mouvement
volatile uint8_t EnLAire = 0;

int T=0;
int H=0;
int P=0;
int V=0;
char cT[5];
char cH[5];
char cP[7];
char cV[5];

char chars[22];  // Tableau pour les caractères
int digits[22];  // Tableau pour les chiffres

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_TIM2_Init(void);
static void MX_ADC_Init(void);
/* USER CODE BEGIN PFP */
void processMotorMovement(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

//Setting up the Microcontroller pins (STM32 L432KC pins A1,A2,A3, and A4)
#define IN1_PIN GPIO_PIN_0
#define IN1_PORT GPIOA
#define IN2_PIN GPIO_PIN_1
#define IN2_PORT GPIOA
#define IN3_PIN GPIO_PIN_1
#define IN3_PORT GPIOC
#define IN4_PIN GPIO_PIN_0
#define IN4_PORT GPIOC

// Step sequence for motor control (half-drive)
const uint8_t step_sequence[8][4] = {
		{1, 0, 0, 0},
		{1, 1, 0, 0},
		{0, 1, 0, 0},
		{0, 1, 1, 0},
		{0, 0, 1, 0},
		{0, 0, 1, 1},
		{0, 0, 0, 1},
		{1, 0, 0, 1}
};

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */
	uint8_t rx_buffer[23];
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
	// Configurer les broches en sortie
	__HAL_RCC_GPIOA_CLK_ENABLE();
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	GPIO_InitStruct.Pin = IN1_PIN | IN2_PIN ;
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = IN3_PIN | IN4_PIN;
	HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_USART1_UART_Init();
  MX_TIM2_Init();
  MX_ADC_Init();
  /* USER CODE BEGIN 2 */

	char *msg = "===== DEMARRAGE SYSTEME =====\r\n";
	HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);

	// Vérification de l'initialisation du Timer
	msg = "Configuration des priorités d'interruption...\r\n";
	HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 100);

	// Configuration des priorités d'interruption
	msg = "Configuration des priorités d'interruption...\r\n";
	HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 100);

	// ADC a une priorité plus élevée (valeur plus basse) que le Timer
	HAL_NVIC_SetPriority(ADC1_IRQn, 0, 0); // Priorité la plus haute pour ADC
	HAL_NVIC_SetPriority(TIM2_IRQn, 2, 0);

	// Arrêter d'abord le Timer s'il est déjà démarré
	HAL_TIM_Base_Stop_IT(&htim2);
	HAL_Delay(10);

	// Démarrage du Timer en mode interruption
	msg = "Démarrage du Timer en interruption...\r\n";
	HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 100);

	if (HAL_TIM_Base_Start_IT(&htim2) != HAL_OK) {
		msg = "ERREUR: Échec du démarrage du Timer!\r\n";
		HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 100);
		Error_Handler();
	} else {
		msg = "Timer démarré avec succès.\r\n";
		HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 100);
	}

	// Démarrage de l'ADC en mode interruption
	msg = "Démarrage de l'ADC en interruption...\r\n";
	HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 100);

	msg = "Vérification de l'état ADC initial...\r\n";
	HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 100);

	char debug_msg[100];
	snprintf(debug_msg, sizeof(debug_msg), "ADC état: %ld, hadc.Instance: 0x%08X\r\n",
			hadc.State, (unsigned int)hadc.Instance);
	HAL_UART_Transmit(&huart2, (uint8_t*)debug_msg, strlen(debug_msg), 100);

	// Dé-initialiser l'ADC avant de le réinitialiser (plus sûr)
	msg = "Dé-initialisation de l'ADC...\r\n";
	HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 100);
	HAL_ADC_DeInit(&hadc);
	HAL_Delay(10); // Petit délai pour s'assurer que la réinitialisation est complète

	// Réinitialiser l'ADC
	msg = "Réinitialisation de l'ADC...\r\n";
	HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 100);
	HAL_StatusTypeDef init_status = HAL_ADC_Init(&hadc);

	if (init_status != HAL_OK) {
		snprintf(debug_msg, sizeof(debug_msg), "ERREUR: Échec init ADC, code: %d\r\n", init_status);
		HAL_UART_Transmit(&huart2, (uint8_t*)debug_msg, strlen(debug_msg), 100);
		Error_Handler();
	} else {
		msg = "ADC initialisé avec succès.\r\n";
		HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 100);
	}

	// Reconfigurer les canaux ADC manuellement (au cas où MX_ADC_Init n'a pas tout configuré correctement)
	ADC_ChannelConfTypeDef sConfig = {0};
	sConfig.Channel = ADC_CHANNEL_6;
	sConfig.Rank = ADC_REGULAR_RANK_1;
	sConfig.SamplingTime = ADC_SAMPLETIME_16CYCLES; // Augmenter le temps d'échantillonnage

	msg = "Configuration du canal ADC...\r\n";
	HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 100);

	if (HAL_ADC_ConfigChannel(&hadc, &sConfig) != HAL_OK) {
		msg = "ERREUR: Échec configuration canal ADC!\r\n";
		HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 100);
		Error_Handler();
	}

	// Configurer le watchdog analogique
	ADC_AnalogWDGConfTypeDef watchdogConfig = {0};
	watchdogConfig.WatchdogMode = ADC_ANALOGWATCHDOG_SINGLE_REG;
	watchdogConfig.Channel = ADC_CHANNEL_6;
	watchdogConfig.ITMode = ENABLE;
	watchdogConfig.HighThreshold = 2482;
	watchdogConfig.LowThreshold = 0;

	msg = "Configuration du watchdog analogique...\r\n";
	HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 100);

	if (HAL_ADC_AnalogWDGConfig(&hadc, &watchdogConfig) != HAL_OK) {
		msg = "ERREUR: Échec configuration watchdog ADC!\r\n";
		HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 100);
		Error_Handler();
	}

	// Vérifier que l'interruption ADC est activée
	msg = "Activation explicite de l'interruption ADC...\r\n";
	HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 100);
	HAL_NVIC_EnableIRQ(ADC1_IRQn);

	// Tenter d'abord un démarrage en mode sans interruption
	msg = "Démarrage ADC en mode normal (sans IT)...\r\n";
	HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 100);

	HAL_StatusTypeDef adc_status = HAL_ADC_Start(&hadc);
	if (adc_status != HAL_OK) {
		char error_msg[50];
		snprintf(error_msg, sizeof(error_msg), "ERREUR ADC START: code %d\r\n", adc_status);
		HAL_UART_Transmit(&huart2, (uint8_t*)error_msg, strlen(error_msg), 100);
		// Ne pas appeler Error_Handler ici, on va essayer une autre approche
	} else {
		msg = "ADC démarré en mode normal.\r\n";
		HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 100);
	}

	// Arrêter l'ADC
	HAL_ADC_Stop(&hadc);
	HAL_Delay(10);

	// Tentative avec le mode IT et configuration plus simple
	// Comme le mode IT ne fonctionne pas, utiliser uniquement le mode polling
	// Configurer l'ADC pour le mode non-IT
	hadc.Init.ContinuousConvMode = ENABLE;  // Mode continu pour simplifier
	hadc.Init.ExternalTrigConv = ADC_SOFTWARE_START;
	hadc.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
	if (HAL_ADC_Init(&hadc) != HAL_OK) {
		msg = "ERREUR: Échec re-init ADC!\r\n";
		HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 100);
		Error_Handler();
	}

	// Configurer les interruptions ADC - on active uniquement le watchdog analogique
	// On désactive les interruptions de conversion standard
	__HAL_ADC_DISABLE_IT(&hadc, ADC_IT_EOC);
	__HAL_ADC_DISABLE_IT(&hadc, ADC_IT_JEOC);
	__HAL_ADC_DISABLE_IT(&hadc, ADC_IT_OVR);

	// Mais on active l'interruption du watchdog analogique
	__HAL_ADC_ENABLE_IT(&hadc, ADC_IT_AWD);

	// S'assurer que l'interruption ADC est active avec une priorité élevée
	HAL_NVIC_SetPriority(ADC1_IRQn, 0, 0); // Priorité maximale
	HAL_NVIC_EnableIRQ(ADC1_IRQn);

	msg = "Démarrage ADC en mode polling (sans IT)...\r\n";
	HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 100);

	if (HAL_ADC_Start(&hadc) != HAL_OK) {
		msg = "ERREUR: Échec démarrage ADC en mode polling!\r\n";
		HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 100);
		Error_Handler();
	}

	msg = "ADC démarré avec succès en mode polling.\r\n";
	HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 100);
	msg = "Demarage de du programme.\r\n";
	HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 100);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
	while (1)
	{
		if(EnMouvement==0)
		{
			// Réception UART non-bloquante avec timeout court (100ms)
			if (HAL_UART_Receive(&huart1, rx_buffer, 23, 1000) == HAL_OK)
			{
				// Données reçues avec succès
				HAL_UART_Transmit(&huart2, rx_buffer, 23, 1000);  // Les renvoyer vers UART2
				process_buffer(rx_buffer, chars, digits, 22);

				V =  conversion(2, 5, rx_buffer, cV);
				T =  conversion(7, 10, rx_buffer, cT);
				H =  conversion(12, 15, rx_buffer, cH);
				P =  conversion(17, 22, rx_buffer, cP);

				intToXString(V, 4,cV);
				intToXString(T, 4,cT);

				intToXString(H,4, cH);
				intToXString(P,6, cP);
				char msg1[10];
				char msg2[12];
				msg = "\r\nV=";
				snprintf(msg, sizeof(msg1), "\r\nV= %c%c%c%c",chars[2], chars[3], chars[4], chars[5] );
				HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 100);

				snprintf(msg, sizeof(msg1), "\r\nV= %c%c%c%c",chars[7], chars[8], chars[9], chars[10] );
				HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 100);


				snprintf(msg, sizeof(msg1), "\r\nV= %c%c%c%c",chars[12], chars[13], chars[14], chars[15] );
				HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 100);

				snprintf(msg, sizeof(msg2), "\r\nV= %c%c%c%c%c%c",chars[17], chars[18], chars[19], chars[20], chars[21], chars[22] );
				HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 100);


				if(V>2000) //--> mouvement angulaire trop violent
				{
					flag_interruption_descente=1;
				}
				if(H>7000)//humidité > 70% -> rique de pluie
				{
					flag_interruption_descente=1;
				}


			}
			msg = ".\r\n";
			HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 100);
			// Petite pause pour laisser souffler le CPU
			HAL_Delay(100);
		}



		// Gestion de l'ADC en mode polling (non-bloquant) dans la boucle principale
		static uint32_t last_adc_check = 0;
		static uint32_t last_info_time = 0;

		// Vérifier l'ADC toutes les 20ms
		if (msCounter - last_adc_check > 20) {
			last_adc_check = msCounter;

			// Lancer une conversion ADC si nécessaire (en mode continu, ce n'est peut-être pas nécessaire)
			if (hadc.State == HAL_ADC_STATE_READY) {
				HAL_ADC_Start(&hadc);
			}

			// Vérifier si la conversion est terminée (non-bloquant)
			if (HAL_ADC_PollForConversion(&hadc, 0) == HAL_OK) {
				// Lire la valeur ADC
				digitalValue = HAL_ADC_GetValue(&hadc);

				// Gérer la LED selon le seuil (équivalent de l'interruption)
				if (digitalValue > 200) {
					HAL_GPIO_WritePin(GPIOB, L0_Pin, GPIO_PIN_SET);
					Vent_violent = 1;
				} else if (Vent_violent == 1) {
					HAL_GPIO_WritePin(GPIOB, L0_Pin, GPIO_PIN_RESET);
					Vent_violent = 0;
				}
			}
		}

		// Afficher l'état toutes les 5 secondes
		if (msCounter - last_info_time > 5000)
		{
			last_info_time = msCounter;

			char info_msg[100];
			snprintf(info_msg, sizeof(info_msg), "INFO: Valeur ADC = %lu, Vent_violent = %d\r\n",
					(unsigned long)digitalValue, (int)Vent_violent);
			HAL_UART_Transmit(&huart2, (uint8_t*)info_msg, strlen(info_msg), 100);

			// Tentative de réinitialisation si l'ADC est arrêté
			if (hadc.State == HAL_ADC_STATE_RESET || hadc.State == HAL_ADC_STATE_ERROR)
			{
				HAL_UART_Transmit(&huart2, (uint8_t*)"Tentative de redémarrage ADC...\r\n", 36, 100);
				HAL_ADC_DeInit(&hadc);
				HAL_Delay(10);
				HAL_ADC_Init(&hadc);
				HAL_ADC_Start(&hadc);

			}
		}

		if(flag_interruption_descente==1 && EnMouvement ==0)
		{
			while(flag_interruption_descente!=0)
			{
				EnMouvement=1;
				last_adc_check = 0;
				last_info_time = 0;
				descente();
				processMotorMovement();
			}
			EnMouvement=0;

		}

		// Traitement du mouvement du moteur dans la boucle principale
		processMotorMovement2();

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	}
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL6;
  RCC_OscInitStruct.PLL.PLLDIV = RCC_PLL_DIV3;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC_Init(void)
{

  /* USER CODE BEGIN ADC_Init 0 */

  /* USER CODE END ADC_Init 0 */

  ADC_AnalogWDGConfTypeDef AnalogWDGConfig = {0};
  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC_Init 1 */

  /* USER CODE END ADC_Init 1 */

  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc.Instance = ADC1;
  hadc.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV1;
  hadc.Init.Resolution = ADC_RESOLUTION_12B;
  hadc.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc.Init.ScanConvMode = ADC_SCAN_ENABLE;
  hadc.Init.EOCSelection = ADC_EOC_SEQ_CONV;
  hadc.Init.LowPowerAutoWait = ADC_AUTOWAIT_DISABLE;
  hadc.Init.LowPowerAutoPowerOff = ADC_AUTOPOWEROFF_DISABLE;
  hadc.Init.ChannelsBank = ADC_CHANNELS_BANK_A;
  hadc.Init.ContinuousConvMode = DISABLE;
  hadc.Init.NbrOfConversion = 1;
  hadc.Init.DiscontinuousConvMode = DISABLE;
  hadc.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc.Init.DMAContinuousRequests = DISABLE;
  if (HAL_ADC_Init(&hadc) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure the analog watchdog
  */
  AnalogWDGConfig.WatchdogMode = ADC_ANALOGWATCHDOG_SINGLE_REG;
  AnalogWDGConfig.Channel = ADC_CHANNEL_6;
  AnalogWDGConfig.ITMode = ENABLE;
  AnalogWDGConfig.HighThreshold = 10;
  AnalogWDGConfig.LowThreshold = 0;
  if (HAL_ADC_AnalogWDGConfig(&hadc, &AnalogWDGConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_6;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_4CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC_Init 2 */

  /* USER CODE END ADC_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 3199;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 1;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 9600;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
	// Configure PA4 (ADC Channel 4) en mode analogique
	GPIO_InitStruct.Pin = GPIO_PIN_4;
	GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, INT4_Pin|INT3_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, INT1_Pin|INT2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, L0_Pin|L1_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : INT4_Pin INT3_Pin */
  GPIO_InitStruct.Pin = INT4_Pin|INT3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : INT1_Pin INT2_Pin */
  GPIO_InitStruct.Pin = INT1_Pin|INT2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : FIN_COURSE_Pin */
  GPIO_InitStruct.Pin = FIN_COURSE_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(FIN_COURSE_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : Digital_IN_Pin */
  GPIO_InitStruct.Pin = Digital_IN_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(Digital_IN_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : L0_Pin L1_Pin */
  GPIO_InitStruct.Pin = L0_Pin|L1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : BTN_2_Pin */
  GPIO_InitStruct.Pin = BTN_2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(BTN_2_GPIO_Port, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI4_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI4_IRQn);

  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

char extract_first_letter(uint8_t *buffer, uint16_t length)
{
	for (uint16_t i = 0; i < length; i++) {
		if (isalpha(buffer[i])) {  // vérifie si c'est une lettre A-Z ou a-z
			return buffer[i];
		}
	}
	return '\0';  // aucun caractère valide trouvé
}

void sendSerialMessage(const char* msg)
{
	HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
}


void stepMotor(int step) {
	HAL_GPIO_WritePin(IN1_PORT, IN1_PIN, step_sequence[step][0]);
	HAL_GPIO_WritePin(IN2_PORT, IN2_PIN, step_sequence[step][1]);
	HAL_GPIO_WritePin(IN3_PORT, IN3_PIN, step_sequence[step][2]);
	HAL_GPIO_WritePin(IN4_PORT, IN4_PIN, step_sequence[step][3]);
}


// Fonction pour tourner de 4 pas dans un sens donné
// Version non-bloquante pour être appelée depuis une interruption
void tourner4pas(int sens, int speed)
{
	// Stocke simplement la demande et les paramètres
	motorDirection = (sens > 0) ? 1 : -1;  // sens > 0 pour gauche, sens <= 0 pour droite
	motorSpeed = speed;
	motorMoveRequested = 4; // Nombre de pas à effectuer
}

// Fonction à appeler dans la boucle principale pour traiter le mouvement du moteur
void processMotorMovement(void)
{
	static int currentStep = 0;


	stepMotor(currentStep);
	currentStep = (currentStep + motorSpeed * motorDirection + 8) % 8;

}
void processMotorMovement2(void)
{
	static uint32_t lastStepTime = 0;
	static int currentStep = 0;

	// Si un mouvement est demandé et assez de temps s'est écoulé depuis le dernier pas
	// Délai de 20ms pour permettre au moteur de compléter son mouvement
	if (motorMoveRequested > 0 && (msCounter - lastStepTime >= 10))
	{
		// Exécute un pas
		stepMotor(currentStep);
		currentStep = (currentStep + motorSpeed * motorDirection + 8) % 8;

		// Décrémente le compteur de pas restants
		motorMoveRequested--;

		// Affiche un message tous les 500 pas
		if (motorMoveRequested % 500 == 0 && motorMoveRequested > 0) {
			char progMsg[50];
			snprintf(progMsg, sizeof(progMsg), "Progression: %d pas restants\r\n", motorMoveRequested);
			HAL_UART_Transmit(&huart2, (uint8_t*)progMsg, strlen(progMsg), 10);
		}

		// Réinitialiser le flag EnMouvement quand le mouvement est terminé
		if (motorMoveRequested == 0) {
			char msg[] = "Mouvement terminé!\r\n";
			HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 100);
			EnMouvement = 0; // Permet au bouton de redéclencher un mouvement
		}

		// Mémorise l'heure du dernier pas
		lastStepTime = msCounter;
	}
}

// Fonction de montée (tourne vers la gauche à vitesse 2)
void montee(void)
{
	// Vérifier si un mouvement est déjà en cours
	if (EnMouvement == 0 && flag_interruption_descente == 0)
	{
		// Si pas de mouvement en cours, démarrer un nouveau
		EnMouvement = 1;
		char msg[] = "Bouton PA12 appuyé: Montée activée pour 4000 pas!\r\n";
		HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 100);

		// Demander un mouvement important (4000 pas)
		motorDirection = 1;  // sens gauche
		motorSpeed = 2;
		motorMoveRequested = 4000;  // 1000 tours de 4 pas
	}
	else
	{
		// Un mouvement est déjà en cours
		char msg[] = "Moteur déjà en mouvement!\r\n";
		HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 100);
	}
}
void descente(void)
{
	char msg[] = "ALERTE! ALERTE! DESCENTE !\r\n";
	HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 100);

	// Demander un mouvement important (4000 pas)
	motorDirection = -1;  // sens gauche
	motorSpeed = 2;
	motorMoveRequested = 1;  // 1000 tours de 4 pas
}

void Turn_Motor(int steps, int speed)
{
	int dir = (steps > 0) ? 1 : -1;
	int stepNum = 0;

	uint32_t start_ms = msCounter;

	// Envoi de l'état initial via série

	for (int i = 0; i < abs(steps); i++)
	{
		// Attente avant de passer à la prochaine étape
		while ((msCounter - start_ms) < 10)
		{
			// Si tu veux déboguer chaque tick, tu peux ajouter ici
			// par exemple une autre information série.
		}

		// Affiche l'état à chaque étape

		stepMotor(stepNum);
		stepNum = (stepNum + speed * dir + 8) % 8;
		start_ms = msCounter;
	}
}

int conversion(int x, int y, uint8_t* str_source, char* str_dest)
{
	int j = 0;
	for (int i = x; i <= y; i++) {
		str_dest[j++] = (char)str_source[i];
	}
	str_dest[j] = '\0';  // Fin de chaîne
	return atoi(str_dest);  // Conversion en entier
}

void intToXString(int value, int width, char* dest)
{
	if (width == 4)
	{
		sprintf(dest, "%04d", value);  // Format pour 4 chiffres
		dest[5] = '\0';
	} else if (width == 6)
	{
		sprintf(dest, "%06d", value);  // Format pour 6 chiffres
		dest[5] = '\0';
	} else {
		// Si une largeur différente est demandée, afficher une erreur ou gérer autrement
		sprintf(dest, "Error");  // Par exemple, renvoyer "Error" pour les autres cas
	}

}

void process_buffer(uint8_t *rx_buffer, char *chars, int *digits, size_t buffer_size)
{
	for (size_t i = 0; i < buffer_size; i++) {
		if (isdigit(rx_buffer[i])) {
			digits[i] = rx_buffer[i] - '0';  // Convertir caractère chiffre en entier
			chars[i] = '\0';  // Mettre un caractère nul si c'est un chiffre
		} else {
			digits[i] = -1;  // Indiquer que c'est une lettre avec -1
			chars[i] = (char)rx_buffer[i];  // Stocker le caractère
		}
	}
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */
	__disable_irq();

	// Envoyer un message d'erreur sur UART avant de bloquer
	char *error_msg = "ERREUR CRITIQUE: Système arrêté!\r\n";
	HAL_UART_Transmit(&huart2, (uint8_t*)error_msg, strlen(error_msg), 1000);

	// Clignoter la LED rapidement pour indiquer une erreur
	while (1)
	{
		HAL_GPIO_TogglePin(GPIOB, L0_Pin);
		for(volatile uint32_t i=0; i<500000; i++); // Délai simple sans utiliser HAL_Delay
	}
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
	/* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
